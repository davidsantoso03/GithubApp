package com.hfad.githubapp.model

class Follower (
    var login: String? = null,
    var avatar_url: String? = null,
    var id :Int? =null,
    var type:String? =null
)