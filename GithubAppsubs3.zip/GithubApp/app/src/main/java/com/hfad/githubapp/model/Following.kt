package com.hfad.githubapp.model

class Following (
    var login: String? = null,
    var avatar_url: String? = null,
    var id:Int? = null,
    var type:String? = null
)